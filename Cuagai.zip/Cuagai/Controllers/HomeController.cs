﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Cuagai.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
        [HttpGet]
        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Login(FormCollection collection)
        {
            string username = collection["username"];
            string password = collection["password"];
            if (username == "ngocdiem" && password == "21122002")
            {
                return RedirectToAction("Index", "Home"); // khuc nay ko pai ghi link login.html ak
                // cái này là backend để cho nó lieê ket voi view á
                //cái này call mới nói hiểu dc thôi à , thi t moi bao la ko pai gih login.html de no lien ket hien trang login in ak
                // a ko can dau OK
            }
            else
            {
                ViewBag.Thongbao = "Nhap sai nhap lai";
            }
            return View();
        }
    }
}